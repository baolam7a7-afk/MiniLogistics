using System.Net.Http.Json;

using MiniLogistics.Web.Models.Auth;

namespace MiniLogistics.Web.Services.Auth;

public class AuthService
{
    private readonly HttpClient _httpClient;
    private readonly TokenStorageService _tokenStorage;


    // =====================================================
    // CONSTRUCTOR
    // =====================================================

    public AuthService(
        HttpClient httpClient,
        TokenStorageService tokenStorage)
    {
        _httpClient = httpClient;
        _tokenStorage = tokenStorage;
    }


    // =====================================================
    // LOGIN EMAIL / PASSWORD
    // =====================================================

    public async Task<AuthResponse?> LoginAsync(
        LoginRequest request)
    {
        var response = await _httpClient.PostAsJsonAsync(
            "api/auth/login",
            request);

        if (!response.IsSuccessStatusCode)
        {
            return null;
        }

        var authResponse =
            await response.Content.ReadFromJsonAsync<AuthResponse>();

        if (authResponse == null)
        {
            return null;
        }

        // Lưu AccessToken + RefreshToken
        // và thông tin user vào Local Storage
        await _tokenStorage.SaveAuthAsync(authResponse);

        return authResponse;
    }


    // =====================================================
    // LOGIN GOOGLE
    // =====================================================

    public async Task<AuthResponse?> GoogleLoginAsync(
        string idToken)
    {
        if (string.IsNullOrWhiteSpace(idToken))
        {
            return null;
        }

        var request = new GoogleLoginRequest
        {
            IdToken = idToken
        };

        var response = await _httpClient.PostAsJsonAsync(
            "api/auth/google",
            request);

        if (!response.IsSuccessStatusCode)
        {
            return null;
        }

        var authResponse =
            await response.Content.ReadFromJsonAsync<AuthResponse>();

        if (authResponse == null)
        {
            return null;
        }

        // Lưu AccessToken + RefreshToken
        // giống Login Email/Password
        await _tokenStorage.SaveAuthAsync(authResponse);

        return authResponse;
    }


    // =====================================================
    // LOGOUT
    // =====================================================

    public async Task LogoutAsync()
    {
        // -------------------------------------------------
        // 1. Lấy Refresh Token hiện tại
        // -------------------------------------------------

        var refreshToken =
            await _tokenStorage.GetRefreshTokenAsync();


        // -------------------------------------------------
        // 2. Gửi Refresh Token lên Backend
        // -------------------------------------------------

        if (!string.IsNullOrWhiteSpace(refreshToken))
        {
            var request = new LogoutRequest
            {
                RefreshToken = refreshToken
            };

            try
            {
                await _httpClient.PostAsJsonAsync(
                    "api/auth/logout",
                    request);
            }
            catch
            {
                // Nếu Backend không kết nối được,
                // Frontend vẫn phải xóa token local.
            }
        }


        // -------------------------------------------------
        // 3. Xóa toàn bộ Authentication data
        // khỏi Local Storage
        // -------------------------------------------------

        await _tokenStorage.RemoveAuthAsync();
    }
}