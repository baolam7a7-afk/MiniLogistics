using Microsoft.JSInterop;

namespace MiniLogistics.Web.Services.Auth;

public class AuthStateService
{
    private readonly IJSRuntime _jsRuntime;

    public AuthStateService(IJSRuntime jsRuntime)
    {
        _jsRuntime = jsRuntime;
    }

    public long UserId { get; private set; }

    public string Email { get; private set; } = string.Empty;

    public string FullName { get; private set; } = string.Empty;

    public List<string> Roles { get; private set; } = new();

    public bool IsAuthenticated { get; private set; }

    public event Action? AuthenticationStateChanged;

    public async Task InitializeAsync()
    {
        var accessToken = await _jsRuntime.InvokeAsync<string?>(
            "localStorage.getItem",
            "accessToken");

        if (string.IsNullOrWhiteSpace(accessToken))
        {
            Clear();
            return;
        }

        var userId = await _jsRuntime.InvokeAsync<string?>(
            "localStorage.getItem",
            "userId");

        var email = await _jsRuntime.InvokeAsync<string?>(
            "localStorage.getItem",
            "email");

        var fullName = await _jsRuntime.InvokeAsync<string?>(
            "localStorage.getItem",
            "fullName");

        var roles = await _jsRuntime.InvokeAsync<string?>(
            "localStorage.getItem",
            "roles");

        if (!long.TryParse(userId, out var parsedUserId))
        {
            Clear();
            return;
        }

        UserId = parsedUserId;
        Email = email ?? string.Empty;
        FullName = fullName ?? string.Empty;

        Roles = string.IsNullOrWhiteSpace(roles)
            ? new List<string>()
            : roles
                .Split(',', StringSplitOptions.RemoveEmptyEntries)
                .Select(x => x.Trim())
                .ToList();

        IsAuthenticated = true;

        AuthenticationStateChanged?.Invoke();
    }

    public bool HasRole(string role)
    {
        return Roles.Any(x =>
            string.Equals(
                x,
                role,
                StringComparison.OrdinalIgnoreCase));
    }

    public void Clear()
    {
        UserId = 0;
        Email = string.Empty;
        FullName = string.Empty;
        Roles = new List<string>();
        IsAuthenticated = false;

        AuthenticationStateChanged?.Invoke();
    }
}