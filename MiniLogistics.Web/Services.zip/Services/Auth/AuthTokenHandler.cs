using System.Net.Http.Headers;

namespace MiniLogistics.Web.Services.Auth;

public class AuthTokenHandler : DelegatingHandler
{
    private readonly TokenStorageService _tokenStorage;

    public AuthTokenHandler(
        TokenStorageService tokenStorage)
    {
        _tokenStorage = tokenStorage;
    }

    protected override async Task<HttpResponseMessage> SendAsync(
        HttpRequestMessage request,
        CancellationToken cancellationToken)
    {
        var accessToken =
            await _tokenStorage.GetAccessTokenAsync();

        if (!string.IsNullOrWhiteSpace(accessToken))
        {
            request.Headers.Authorization =
                new AuthenticationHeaderValue(
                    "Bearer",
                    accessToken);
        }

        return await base.SendAsync(
            request,
            cancellationToken);
    }
}