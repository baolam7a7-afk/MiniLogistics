using System.Net.Http.Json;
using MiniLogistics.Web.Models.Product;

namespace MiniLogistics.Web.Services.Auth;

public class ProductService
{
    private readonly HttpClient _httpClient;

    public ProductService(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }

    public async Task<List<ProductResponse>> GetProductsAsync()
    {
        var response = await _httpClient.GetAsync("api/products");

        if (!response.IsSuccessStatusCode)
        {
            return new List<ProductResponse>();
        }

        var products =
            await response.Content.ReadFromJsonAsync<List<ProductResponse>>();

        return products ?? new List<ProductResponse>();
    }
    public async Task<ProductDetailResponse?> GetProductByIdAsync(long id)
    {
        var response = await _httpClient.GetAsync(
            $"api/products/{id}");

        if (!response.IsSuccessStatusCode)
        {
            return null;
        }

        return await response.Content
            .ReadFromJsonAsync<ProductDetailResponse>();
    }
    public async Task<List<ProductVariantResponse>> GetVariantsByProductIdAsync(long productId)
    {
        var response = await _httpClient.GetAsync(
            $"api/product-variants/product/{productId}");

        if (!response.IsSuccessStatusCode)
        {
            return new List<ProductVariantResponse>();
        }

        var variants =
            await response.Content
                .ReadFromJsonAsync<List<ProductVariantResponse>>();

        return variants ?? new List<ProductVariantResponse>();
    }
}