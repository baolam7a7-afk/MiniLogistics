using Microsoft.JSInterop;
using MiniLogistics.Web.Models.Auth;

namespace MiniLogistics.Web.Services.Auth;

public class TokenStorageService
{
    private readonly IJSRuntime _jsRuntime;

    public TokenStorageService(IJSRuntime jsRuntime)
    {
        _jsRuntime = jsRuntime;
    }


    public async Task SaveAuthAsync(AuthResponse auth)
    {
        await _jsRuntime.InvokeVoidAsync(
            "localStorage.setItem",
            "accessToken",
            auth.AccessToken);

        await _jsRuntime.InvokeVoidAsync(
            "localStorage.setItem",
            "refreshToken",
            auth.RefreshToken);

        await _jsRuntime.InvokeVoidAsync(
            "localStorage.setItem",
            "userId",
            auth.UserId.ToString());

        await _jsRuntime.InvokeVoidAsync(
            "localStorage.setItem",
            "email",
            auth.Email);

        await _jsRuntime.InvokeVoidAsync(
            "localStorage.setItem",
            "fullName",
            auth.FullName);

        await _jsRuntime.InvokeVoidAsync(
            "localStorage.setItem",
            "roles",
            string.Join(",", auth.Roles));
    }


    public async Task<string?> GetAccessTokenAsync()
    {
        return await _jsRuntime.InvokeAsync<string?>(
            "localStorage.getItem",
            "accessToken");
    }


    public async Task<string?> GetRefreshTokenAsync()
    {
        return await _jsRuntime.InvokeAsync<string?>(
            "localStorage.getItem",
            "refreshToken");
    }


    public async Task RemoveAuthAsync()
    {
        await _jsRuntime.InvokeVoidAsync(
            "localStorage.removeItem",
            "accessToken");

        await _jsRuntime.InvokeVoidAsync(
            "localStorage.removeItem",
            "refreshToken");

        await _jsRuntime.InvokeVoidAsync(
            "localStorage.removeItem",
            "userId");

        await _jsRuntime.InvokeVoidAsync(
            "localStorage.removeItem",
            "email");

        await _jsRuntime.InvokeVoidAsync(
            "localStorage.removeItem",
            "fullName");

        await _jsRuntime.InvokeVoidAsync(
            "localStorage.removeItem",
            "roles");
    }
    public async Task UpdateTokensAsync(
    string accessToken,
    string refreshToken)
    {
        await _jsRuntime.InvokeVoidAsync(
            "localStorage.setItem",
            "accessToken",
            accessToken);

        await _jsRuntime.InvokeVoidAsync(
            "localStorage.setItem",
            "refreshToken",
            refreshToken);
    }
}